/**
 * @rewindrewind/node — server-side SDK for Node and Bun.
 *
 * Zero runtime dependencies: built entirely on the global `fetch` and standard
 * `process` hooks. Capture calls never throw into your application code.
 *
 * @example
 * ```ts
 * import { init, captureException } from "@rewindrewind/node";
 *
 * init({ projectKey: process.env.REWINDREWIND_PROJECT_KEY!, environment: "production" });
 *
 * try {
 *   risky();
 * } catch (err) {
 *   await captureException(err);
 * }
 * ```
 */

import { parseStackTrace, type StackFrame } from "./stacktrace.js";
import { post, type TransportResult } from "./transport.js";

export { parseStackTrace, isInApp } from "./stacktrace.js";
export type { StackFrame } from "./stacktrace.js";
export type { TransportResult } from "./transport.js";

const DEFAULT_ENDPOINT = "https://rewindrewind.com";
const DEFAULT_TIMEOUT_MS = 2000;
const MAX_ENVIRONMENT_LENGTH = 64;

export type Platform = "node" | "bun" | "cloudflare" | "deno";

export interface RewindUser {
  id?: string;
  email?: string;
  [key: string]: unknown;
}

export interface RewindRequest {
  method?: string;
  url?: string;
  headers?: Record<string, string>;
  query_string?: string;
  data?: unknown;
  [key: string]: unknown;
}

export interface RewindConfig {
  /** Public project ingestion key (`rrpub_…`). Required. */
  projectKey: string;
  /** Deployment environment, e.g. "production". Required, non-empty, ≤64 chars. */
  environment: string;
  /** API origin. Defaults to `REWINDREWIND_ENDPOINT` env or https://rewindrewind.com. */
  endpoint?: string;
  /** Release identifier (version / git sha). */
  release?: string;
  /** Per-request timeout in ms, enforced via AbortController. Default 2000. */
  timeoutMs?: number;
  /** Default user attached to every exception. */
  user?: RewindUser;
  /** Default tags merged into every exception. */
  tags?: Record<string, unknown>;
  /** Default extra context merged into every exception. */
  extra?: Record<string, unknown>;
  /** Log transport activity to console. Default false. */
  debug?: boolean;
}

export interface CaptureExceptionOptions {
  /** Override the derived message. */
  message?: string;
  /** Stable grouping key; overrides the server's culprit-based grouping. */
  fingerprint?: string | string[];
  /** Severity. Defaults to "error". */
  level?: string;
  user?: RewindUser;
  request?: RewindRequest;
  tags?: Record<string, unknown>;
  extra?: Record<string, unknown>;
}

/** Resolve the runtime platform once, at module load. */
export function detectPlatform(): Platform {
  const g = globalThis as {
    Bun?: unknown;
    Deno?: unknown;
    navigator?: { userAgent?: string };
    WebSocketPair?: unknown;
  };
  // Bun exposes a global `Bun` object and `process.versions.bun`.
  if (typeof g.Bun !== "undefined") return "bun";
  const versions = (globalThis as { process?: { versions?: Record<string, string> } })
    .process?.versions;
  if (versions && typeof versions.bun === "string") return "bun";
  // Cloudflare Workers (workerd) report a fixed navigator UA and expose the
  // Workers-only `WebSocketPair` global — checked before `node` because
  // `nodejs_compat` polyfills a partial `process`.
  if (g.navigator?.userAgent === "Cloudflare-Workers" || typeof g.WebSocketPair !== "undefined") {
    return "cloudflare";
  }
  // Deno exposes a global `Deno` namespace.
  if (typeof g.Deno !== "undefined") return "deno";
  return "node";
}

const PLATFORM: Platform = detectPlatform();

interface NormalizedError {
  type: string;
  value: string;
  message: string;
  stacktrace: StackFrame[];
}

/**
 * A configured RewindRewind client. Construct one per project key, or use the
 * module-level {@link init} / {@link captureException} convenience API.
 */
export class RewindClient {
  private readonly projectKey: string;
  private readonly endpoint: string;
  private readonly environment: string;
  private readonly release?: string;
  private readonly timeoutMs: number;
  private readonly defaultUser?: RewindUser;
  private readonly defaultTags?: Record<string, unknown>;
  private readonly defaultExtra?: Record<string, unknown>;
  private readonly debug: boolean;

  /** In-flight requests, awaited by {@link flush}. */
  private pending = new Set<Promise<unknown>>();
  private uninstall?: () => void;

  constructor(config: RewindConfig) {
    const projectKey = (config.projectKey ?? "").trim();
    if (!projectKey) {
      throw new Error("RewindRewind: `projectKey` is required");
    }
    const environment = (config.environment ?? "").trim();
    if (!environment) {
      throw new Error("RewindRewind: `environment` is required and must be non-empty");
    }
    if (environment.length > MAX_ENVIRONMENT_LENGTH) {
      throw new Error(
        `RewindRewind: \`environment\` must be ≤${MAX_ENVIRONMENT_LENGTH} characters`,
      );
    }

    this.projectKey = projectKey;
    this.endpoint = (
      config.endpoint ??
      readEnv("REWINDREWIND_ENDPOINT") ??
      DEFAULT_ENDPOINT
    ).replace(/\/+$/, "");
    this.environment = environment;
    this.release = config.release ?? readEnv("REWINDREWIND_RELEASE");
    this.timeoutMs = config.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    this.defaultUser = config.user;
    this.defaultTags = config.tags;
    this.defaultExtra = config.extra;
    this.debug = config.debug ?? false;
  }

  /** The runtime platform reported in exception payloads ("node" | "bun"). */
  get platform(): Platform {
    return PLATFORM;
  }

  /**
   * Report an exception. Resolves with the transport result; never throws —
   * transport and serialization errors are caught and (when `debug`) logged.
   */
  captureException(
    error: unknown,
    options: CaptureExceptionOptions = {},
  ): Promise<TransportResult> {
    try {
      const normalized = normalizeError(error);
      const payload: Record<string, unknown> = {
        timestamp: Date.now(),
        environment: this.environment,
        release: this.release,
        platform: PLATFORM,
        level: options.level ?? "error",
        message: options.message ?? normalized.message,
        exception: {
          type: normalized.type,
          value: normalized.value,
          stacktrace: normalized.stacktrace,
        },
        fingerprint: normalizeFingerprint(options.fingerprint),
        request: options.request,
        user: mergeUser(this.defaultUser, options.user),
        tags: mergeRecords(this.defaultTags, options.tags),
        extra: mergeRecords(this.defaultExtra, options.extra),
      };
      return this.send("/v1/exceptions", prune(payload));
    } catch (err) {
      return this.swallow(err);
    }
  }

  /**
   * Report a product/analytics event. `type` is required.
   */
  captureEvent(
    type: string,
    properties: Record<string, unknown> = {},
    options: {
      distinctId?: string;
      anonymousId?: string;
      source?: string;
    } = {},
  ): Promise<TransportResult> {
    try {
      const payload: Record<string, unknown> = {
        type,
        environment: this.environment,
        release: this.release,
        distinct_id: options.distinctId ?? this.defaultUser?.id,
        anonymous_id: options.anonymousId,
        source: options.source ?? PLATFORM,
        properties,
      };
      return this.send("/v1/events", prune(payload));
    } catch (err) {
      return this.swallow(err);
    }
  }

  /**
   * Install global handlers for `uncaughtException` and `unhandledRejection`,
   * reporting each before the process continues. Returns this client for
   * chaining. Idempotent: a second call is a no-op until {@link close}.
   */
  install(): this {
    if (this.uninstall) return this;
    const proc = (globalThis as { process?: NodeProcess }).process;
    if (!proc || typeof proc.on !== "function") {
      this.log("install: no `process` available; skipping global handlers");
      return this;
    }

    const onUncaught = (err: unknown): void => {
      void this.captureException(err, { extra: { handler: "uncaughtException" } });
    };
    const onRejection = (reason: unknown): void => {
      void this.captureException(reason, { extra: { handler: "unhandledRejection" } });
    };

    proc.on("uncaughtException", onUncaught);
    proc.on("unhandledRejection", onRejection);

    this.uninstall = () => {
      proc.off?.("uncaughtException", onUncaught);
      proc.off?.("unhandledRejection", onRejection);
    };
    return this;
  }

  /** Remove any global handlers registered by {@link install}. */
  close(): void {
    this.uninstall?.();
    this.uninstall = undefined;
  }

  /** Await all in-flight captures. Resolves once the queue drains. */
  async flush(): Promise<void> {
    await Promise.allSettled([...this.pending]);
  }

  private send(path: string, body: unknown): Promise<TransportResult> {
    const promise = post(path, body, {
      endpoint: this.endpoint,
      apiKey: this.projectKey,
      timeoutMs: this.timeoutMs,
      debug: this.debug,
    });
    this.pending.add(promise);
    void promise.finally(() => this.pending.delete(promise));
    return promise;
  }

  private swallow(err: unknown): Promise<TransportResult> {
    this.log("capture failed before send", err);
    return Promise.resolve({ ok: false, status: 0, error: errorMessage(err) });
  }

  private log(...args: unknown[]): void {
    if (this.debug && typeof console !== "undefined") {
      console.debug("[rewindrewind]", ...args);
    }
  }
}

/* -------------------------------------------------------------------------- */
/* Module-level convenience API                                               */
/* -------------------------------------------------------------------------- */

let defaultClient: RewindClient | undefined;

/**
 * Initialize the default client used by the module-level
 * {@link captureException} / {@link captureEvent} / {@link flush} helpers.
 */
export function init(config: RewindConfig): RewindClient {
  defaultClient = new RewindClient(config);
  return defaultClient;
}

/** The default client created by {@link init}, if any. */
export function getClient(): RewindClient | undefined {
  return defaultClient;
}

function requireClient(): RewindClient {
  if (!defaultClient) {
    throw new Error("RewindRewind: call init(config) before using the default client");
  }
  return defaultClient;
}

export function captureException(
  error: unknown,
  options?: CaptureExceptionOptions,
): Promise<TransportResult> {
  return requireClient().captureException(error, options);
}

export function captureEvent(
  type: string,
  properties?: Record<string, unknown>,
  options?: { distinctId?: string; anonymousId?: string; source?: string },
): Promise<TransportResult> {
  return requireClient().captureEvent(type, properties, options);
}

export function flush(): Promise<void> {
  return requireClient().flush();
}

/* -------------------------------------------------------------------------- */
/* Internals                                                                  */
/* -------------------------------------------------------------------------- */

interface NodeProcess {
  on(event: string, listener: (...args: unknown[]) => void): unknown;
  off?(event: string, listener: (...args: unknown[]) => void): unknown;
}

/** Convert any thrown value into structured exception fields. */
function normalizeError(error: unknown): NormalizedError {
  if (error instanceof Error) {
    return {
      type: error.name || "Error",
      value: error.message,
      message: error.message || error.name || "Error",
      stacktrace: parseStackTrace(error.stack),
    };
  }

  if (error && typeof error === "object") {
    const obj = error as Record<string, unknown>;
    const value =
      typeof obj.message === "string" ? obj.message : safeStringify(error);
    const type = typeof obj.name === "string" ? obj.name : "Error";
    const stack = typeof obj.stack === "string" ? obj.stack : undefined;
    return { type, value, message: value, stacktrace: parseStackTrace(stack) };
  }

  const value = String(error);
  return { type: "Error", value, message: value, stacktrace: [] };
}

function normalizeFingerprint(
  fingerprint: string | string[] | undefined,
): string | undefined {
  if (fingerprint === undefined) return undefined;
  return Array.isArray(fingerprint) ? fingerprint.join(":") : fingerprint;
}

function mergeUser(
  base: RewindUser | undefined,
  override: RewindUser | undefined,
): RewindUser | undefined {
  if (!base && !override) return undefined;
  return { ...base, ...override };
}

function mergeRecords(
  base: Record<string, unknown> | undefined,
  override: Record<string, unknown> | undefined,
): Record<string, unknown> | undefined {
  if (!base && !override) return undefined;
  return { ...base, ...override };
}

/** Drop `undefined` top-level fields so we send a clean payload. */
function prune(obj: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) out[key] = value;
  }
  return out;
}

function readEnv(name: string): string | undefined {
  const env = (globalThis as { process?: { env?: Record<string, string | undefined> } })
    .process?.env;
  const value = env?.[name];
  return value && value.length > 0 ? value : undefined;
}

function safeStringify(value: unknown): string {
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}

function errorMessage(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}
